// API/index.js
import app from '../backend/src/app.js';

export default app;
